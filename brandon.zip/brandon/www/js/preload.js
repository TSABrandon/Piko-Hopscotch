preloadGame = {
	preload:function(){
	   game.load.image('sky','img/sky.png');
       game.load.image('bg','img/bg.png');
       game.load.image('gg','img/gg.png');
       game.load.image('ff','img/ff.png');
	   game.load.image('platform','img/platform.png'); 
	   game.load.image('diamond','img/diamond.png');
	   game.load.image('btnLeft', 'img/btnLeft.png');
	   game.load.image('btnRight', 'img/btnRight.png');
	   game.load.image("buttonplay","img/playButton.png");
	game.load.image('btnRight', 'img/btnRight.png');
	game.load.image('ins','img/instruction.png');
	 game.load.image('intruct',"img/patakaran.png");
	game.load.image('About','img/aboutbtn.png');
	game.load.image('about2','img/about2.png');
	    	game.load.spritesheet("menu2","img/menu2.png",80,50);
       game.load.spritesheet('startButton','img/start.png',800,600);
	   game.load.spritesheet('dude','img/dude.png',32,48);
	   game.load.spritesheet('btn-play','img/btn-green.png',285,250);
	   game.load.spritesheet('btn1','img/btn-up.png',100,100);
  
    },

    create: function(){
    	game.state.start("menuGame");

    	},
    }