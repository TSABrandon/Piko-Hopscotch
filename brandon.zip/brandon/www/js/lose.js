loseGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
}