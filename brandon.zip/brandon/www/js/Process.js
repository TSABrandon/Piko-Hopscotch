var proseso = function(){
    "use strict";
    return {

    	//var a = 0;
killDiamond: function (player,diamond){
					var score = 0;
					score = score+ 5;
					diamond.kill();
				if(proseso.getScore()<=score){
        saveScore(score);
        bestScoreText.text = "Best: "+score;
    }

    time.text = "Score: "+score;
				
},
killDude: function (player,ff, gg){
     game._paused = true;
     //player.kill();   
        
                stateText.text =" GAME OVER\n\n Tap to restart";
                stateText.visible = true;
            
                game.input.onTap.addOnce(proseso.restart,this);
            

},
saveScore: function (Score){
    localStorage.setItem("gameScore",Score);
},

getScore: function (){
    return (localStorage.getItem("gameScore") == null || localStorage.getItem("gameScore") == "")?0:localStorage.getItem("gameScore");

},
pushright: function (){
    player.animations.play('walk-right');
	player.body.velocity.x=150;

    setTimeout(function(){
    

    },100);
	//bg.tilePosition.x -=4;
},
pushleft: function(){
	player.animations.play('walk-left');
	player.body.velocity.x = -150;


    setTimeout(function(){

    },100);
	//bg.tilePosition.x -=4;
},
palundaginSiNaruto: function (){
    player.body.velocity.y = -500;

    button_Lundag.frame = 1;

    setTimeout(function(){
        button_Lundag.frame = 0;

    },100);
},
startGame: function(){
    startButton.destroy();
    player.body.velocity.set(0,0);
    proseso.playing = true;
    
     },	
playGame: function (){
    setTimeout(function(){
        button_Galaw.frame = 0;
        game._paused = false;
     },5000);

    game._paused = true;
    button_Galaw.frame = 1;
},
restart: function () {

   
    window.location.href=window.location.href;
    stateText.visible = false;

}
 }
}();