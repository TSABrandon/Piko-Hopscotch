bootGame = {
	create:function(){
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.stage.backgroundColor = "#ccc"
		keyboard = game.input.keyboard.createCursorKeys();
		game.world.setBounds(0,0,bounds,0);
		game.state.start("preloadGame");

	}

}