menuGame = {
	create:function(){
		bg = game.add.image(0,0,"bg")


		 startButton = game.add.button(450,150, "buttonplay",this.buttonPlay);

    aboutText = game.add.button(450,450,"About",this.about);
            //aboutText.anchor.set(0.6);
            //aboutText.scale.set(1);  

    menuText = game.add.text(450, 50,"Menu",{"fill":"#fff000"});
    menuText.scale.x = 2;
    menuText.scale.y = 2;

    instruc = game.add.button(420,270,"intruct",this.ins);
            //instruc.anchor.set(0.6);
            //instruc.scale.set(1);

	
},

 about: function(){
            about=game.add.image(0,0,"about2");
            //about.scale.set(3.2);
        
            
            restartButton=game.add.button(30,30,"menu2",restartB,this);
            function restartB() {
           
            restartButton.destroy();
            game.state.start("menuGame");
            }

            },

            ins: function(){
            about=game.add.image(0,0,"ins");
            //about.scale.set(3.2);
            

            restartButton=game.add.button(30,30,"menu2",restartB,this);
            function restartB() {
            restartButton.destroy();

            game.state.start("menuGame");

            }

            },
   

            buttonPlay:function(){
                game.state.start("playGame");
                //menumusic.stop();
        
            },
update:function(){
	   //if(keyboard.up.isDown){
	   	 // game.state.start("playGame");
	 //}
}
}